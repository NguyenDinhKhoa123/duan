function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        document.getElementById("output").innerHTML = "Trình duyệt của bạn không hỗ trợ định vị.";
    }
}

function showPosition(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    document.getElementById("output").innerHTML = 
        "Vĩ độ (Latitude): " + latitude + "<br>" +
        "Kinh độ (Longitude): " + longitude;
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            document.getElementById("output").innerHTML = "Người dùng từ chối chia sẻ vị trí.";
            break;
        case error.POSITION_UNAVAILABLE:
            document.getElementById("output").innerHTML = "Không thể lấy thông tin vị trí.";
            break;
        case error.TIMEOUT:
            document.getElementById("output").innerHTML = "Yêu cầu lấy vị trí đã hết thời gian.";
            break;
        case error.UNKNOWN_ERROR:
            document.getElementById("output").innerHTML = "Đã xảy ra lỗi không xác định.";
            break;
    }
}