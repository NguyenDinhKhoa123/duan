const myVideo = document.getElementById("myVideo");

        function playPause() {
            if (myVideo.paused)
                myVideo.play();
            else
                myVideo.pause();
        }
        function replayVideo() {
            myVideo.currentTime = 0;
            myVideo.play();
        }

        function volumeUp() {
            if (myVideo.volume < 1) myVideo.volume += 0.1;
        }

        function volumeDown() {
            if (myVideo.volume > 0) myVideo.volume -= 0.1;
        }

        function muteUnmute() {
            myVideo.muted = !myVideo.muted;
        }