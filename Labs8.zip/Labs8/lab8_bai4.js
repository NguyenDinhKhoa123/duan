const endDate = document.querySelector("input[name='endDate']");
        const clock = document.querySelector(".clock");
        let timeInterval;
        let timeStop = true;

        // Lấy giá trị lưu trong localStorage (nếu có)
        const savedValue = localStorage.getItem("countdown") || false;
        if (savedValue) {
            startClock(savedValue);
            let inputValue = new Date(savedValue);
            endDate.valueAsDate = inputValue;
        }

        // Khi người dùng chọn ngày mới, bắt đầu lại đồng hồ đếm ngược
        endDate.addEventListener("change", function (e) {
            e.preventDefault();
            clearInterval(timeInterval);
            const temp = new Date(endDate.value);
            localStorage.setItem("countdown", temp);
            startClock(temp);
            timeStop = true;
        });

        // Hàm tính thời gian còn lại
        function tinhThoiGianConLai(d) {
            let ngayHienTai = new Date();
            let t = Date.parse(d) - Date.parse(ngayHienTai);

            let giay = Math.floor((t / 1000) % 60);
            let phut = Math.floor((t / (1000 * 60)) % 60);
            let gio = Math.floor((t / (1000 * 60 * 60)) % 24);
            let ngay = Math.floor(t / (1000 * 60 * 60 * 24));

            return {
                "tongThoiGian": t,
                "ngay": ngay,
                "gio": gio,
                "phut": phut,
                "giay": giay
            };
        }

        // Hàm bắt đầu đồng hồ đếm ngược
        function startClock(d) {
            function updateClock() {
                let t = tinhThoiGianConLai(d);
                clock.innerHTML = 
                    "Còn lại: " + t.ngay + " ngày " +
                    t.gio + " giờ " +
                    t.phut + " phút " +
                    t.giay + " giây ";

                if (t.tongThoiGian <= 0) {
                    clearInterval(timeInterval);
                    clock.innerHTML = "Hết thời gian!";
                }
            }

            updateClock(); // chạy ngay lập tức
            timeInterval = setInterval(updateClock, 1000);
        }