package poly.cafe.entity;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.Data;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data

public class Bill {
    
    public enum Status {
        Servicing,
        Completed,
        Canceled
    }
    
    
 private Long id;
 private String username;
 private Integer cardId;
 @Builder.Default
 
 private Date checkin = new Date();
 private Date checkout;
 private int status;
 
}
