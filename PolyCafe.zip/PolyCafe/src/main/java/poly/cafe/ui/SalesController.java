package poly.cafe.ui;

/**
 *
 * @author khuon
 */
public interface SalesController {

    void open(); // tải và hiển thị thẻ lên cửa sổ bán hàng

    void showBillJDialog(int cardId); // hiển thị cửa sổ chứa phiếu bán hàng hàng của 1 thẻ
}
