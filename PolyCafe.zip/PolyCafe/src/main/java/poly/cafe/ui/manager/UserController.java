package poly.cafe.ui.manager;

import poly.cafe.entity.User;

/**
 *
 * @author khuon
 */
public interface UserController extends CrudController<User> {
    
}
