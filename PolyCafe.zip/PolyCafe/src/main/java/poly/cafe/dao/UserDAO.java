package poly.cafe.dao;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */


import poly.cafe.entity.User;

/**
 *
 * @author khuon
 */
public interface UserDAO extends CrudDAO<User, String>{
    
}
