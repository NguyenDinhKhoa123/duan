/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package poly.cafe.dao;

import java.util.List;

/**
 *
 * @author khuon
 * @param <T>
 * @param <ID>
 */
public interface CrudDAO<T, ID> {
    T create(T entity);  // Tạo mới
    void update(T entity);  // Cập nhật
    void deleteById(ID id);  // Xóa theo ID
    List<T> findAll();  // Lấy tất cả các bản ghi
    T findById(ID id);  // Lấy bản ghi theo ID
}

