package poly.cafe.dao;

import poly.cafe.entity.Category;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */


/**
 *
 * @author khuon
 */
public interface CategoryDAO extends CrudDAO<Category, String> {

}
