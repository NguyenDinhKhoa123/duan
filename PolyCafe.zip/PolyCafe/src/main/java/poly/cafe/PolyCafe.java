/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package poly.cafe;

import poly.cafe.ui.PolyCafeJFrame;

/**
 *
 * @author Admin
 */
public class PolyCafe {

    public static void main(String[] args) {
new PolyCafeJFrame().setVisible(true);
    }
}
