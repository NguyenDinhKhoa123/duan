package poly.cafe.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import poly.cafe.entity.Category;

public class Test {

//    public static void main(String[] args) throws SQLException {
//        System.out.println("Test db");
//        selectCategories();
//    }
//
//    public static void insertCategories() {
//        String sql = "INSERT INTO Categories (Id, Name) VALUES(?, ?)";
//        XJdbc.executeUpdate(sql, "C01", "Loai 1");
//        XJdbc.executeUpdate(sql, "C02", "Loai 2");
//    }
//
//    public static void selectCategories() throws SQLException {
//        String sql = "SELECT * FROM Categories WHERE Name LIKE ?";
//        ResultSet rs = XJdbc.executeQuery(sql, "%Loai%");
//        System.out.println("Co gia tri tra ve: " + rs.next());
//    }
//
//    public static List<Category> selectCategoriesToList() throws SQLException {
//        // Đoạn code này có vẻ như đang bị bỏ trống trong ảnh chụp màn hình.
//        // Nếu bạn muốn tôi viết ra một ví dụ, hãy cho tôi biết cấu trúc của lớp Category nhé!
//        return null; // Tạm thời trả về null vì không có nội dung trong ảnh.
//    }
    
    

}
