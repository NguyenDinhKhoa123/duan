package poly.cafe.ui.manager;

import poly.cafe.entity.Card;

public interface CardController extends CrudController<Card>{
}

