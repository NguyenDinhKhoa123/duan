package poly.cafe.ui.manager;

import poly.cafe.entity.Category;

public interface CategoryController extends CrudController<Category>{
}

