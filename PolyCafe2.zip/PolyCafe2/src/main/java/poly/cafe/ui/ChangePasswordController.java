package poly.cafe.ui;

public interface ChangePasswordController {
    void open();
    void save();
    void close();
}
