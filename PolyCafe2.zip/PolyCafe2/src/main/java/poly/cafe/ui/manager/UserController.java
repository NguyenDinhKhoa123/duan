package poly.cafe.ui.manager;

import poly.cafe.entity.User;

public interface UserController extends CrudController<User>{
}

