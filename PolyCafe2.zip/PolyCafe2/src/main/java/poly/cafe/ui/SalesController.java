package poly.cafe.ui;

public interface SalesController {
    void open();
    void showBillJDialog(int cardId);
}
