package poly.cafe.ui.manager;

import poly.cafe.entity.Customer;




public interface CustomerController extends CrudController<Customer>{
    
}
