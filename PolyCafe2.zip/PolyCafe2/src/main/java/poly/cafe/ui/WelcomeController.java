package poly.cafe.ui;

public interface WelcomeController {
    void waiting();
}
