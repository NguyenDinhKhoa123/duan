package poly.cafe.dao;

import poly.cafe.entity.Card;

public interface CardDAO extends CrudDAO<Card, Integer>{
    
}
