package poly.cafe.dao;

import poly.cafe.entity.Category;

public interface CategoryDAO extends CrudDAO<Category, String>{
    
}
