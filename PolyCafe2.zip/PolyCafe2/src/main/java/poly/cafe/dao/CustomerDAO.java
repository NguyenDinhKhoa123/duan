package poly.cafe.dao;


import poly.cafe.entity.Customer;

public interface CustomerDAO extends CrudDAO<Customer, String>{
    
}
