package poly.cafe.dao.impl;

import java.util.List;
import poly.cafe.dao.CustomerDAO;
import poly.cafe.entity.Customer;
import poly.cafe.util.XJdbc;
import poly.cafe.util.XQuery;

public class CustomerDAOImpl implements CustomerDAO {

    private final String createSql = "INSERT INTO Customers (CustomerId, Fullname, Address, Phone) VALUES (?, ?, ?, ?)";
    private final String updateSql = "UPDATE Customers SET Fullname = ?, Address = ?, Phone = ? WHERE CustomerId = ?";
    private final String deleteByIdSql = "DELETE FROM Customers WHERE CustomerId = ?";
    
    private final String findAllSql = "SELECT * FROM Customers";
    private final String findByIdSql = findAllSql + " WHERE CustomerId = ?";

    @Override
    public Customer create(Customer entity) {
        Object[] values = {
            entity.getCustomerId(),
            entity.getFullname(),
            entity.getAddress(),       // sửa từ getDiaChi()
            entity.getPhone()
        };
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(Customer entity) {
        Object[] values = {
            entity.getFullname(),
            entity.getAddress(),       // sửa từ getDiaChi()
            entity.getPhone(),
            entity.getCustomerId()
        };
        XJdbc.executeUpdate(updateSql, values);
    }

    @Override
    public void deleteById(String customerId) {
        XJdbc.executeUpdate(deleteByIdSql, customerId);
    }

    @Override
    public List<Customer> findAll() {
        return XQuery.getBeanList(Customer.class, findAllSql);
    }

    @Override
    public Customer findById(String customerId) {
        return XQuery.getSingleBean(Customer.class, findByIdSql, customerId);
    }
}
