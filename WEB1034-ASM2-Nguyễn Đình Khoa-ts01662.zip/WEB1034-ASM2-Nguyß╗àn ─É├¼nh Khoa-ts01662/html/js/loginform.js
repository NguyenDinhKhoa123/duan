function login() {
  const username = document.getElementById("tendangnhap").value.trim();
  const password = document.getElementById("matkhau").value;
  const message = document.getElementById("message");

  // Reset màu mặc định cho thông báo lỗi
  message.style.color = "red";

  // Kiểm tra nhập liệu trống
  if (username === "" || password === "") {
    message.textContent = "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.";
    return;
  }

  const savedPassword = localStorage.getItem(username);

  if (!savedPassword) {
    message.textContent = "Tài khoản không tồn tại.";
    return;
  }

  if (password === savedPassword) {
    message.style.color = "#90C67C"; // Màu xanh thành công
    message.textContent = "Đăng nhập thành công!";

    // Lưu username để dùng trên các trang khác
    localStorage.setItem("loggedInUser", username);

    setTimeout(() => {
      window.location.href = "trangchu.html";
    }, 1000);
  } else {
    message.textContent = "Sai mật khẩu.";
  }
}
