function register() {
  const username = document.getElementById("tendangnhap").value.trim();
  const password = document.getElementById("matkhau").value;
  const message = document.getElementById("message");
  message.style.color = "red";  // Mặc định màu lỗi

  // Kiểm tra nhập liệu trống
  if (username === "" || password === "") {
    message.textContent = "Vui lòng nhập đầy đủ thông tin.";
    return;
  }

  // Kiểm tra độ dài username
  if (username.length < 4) {
    message.textContent = "Tên đăng nhập phải có ít nhất 4 ký tự.";
    return;
  }

  // Kiểm tra ký tự hợp lệ trong username (chỉ cho phép chữ, số, dấu gạch dưới)
  const usernameRegex = /^[a-zA-Z0-9_]+$/;
  if (!usernameRegex.test(username)) {
    message.textContent = "Tên đăng nhập chỉ được chứa chữ cái, số và dấu gạch dưới.";
    return;
  }

  // Kiểm tra độ dài mật khẩu
  if (password.length < 6) {
    message.textContent = "Mật khẩu phải có ít nhất 6 ký tự.";
    return;
  }

  // Kiểm tra mật khẩu có ít nhất 1 chữ hoa, 1 chữ thường và 1 số
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
  if (!passwordRegex.test(password)) {
    message.textContent = "Mật khẩu phải chứa ít nhất 1 chữ hoa, 1 chữ thường và 1 số.";
    return;
  }

  // Kiểm tra username đã tồn tại chưa
  if (localStorage.getItem(username)) {
    message.textContent = "Tên đăng nhập đã tồn tại.";
    return;
  }

  // Lưu thông tin tài khoản vào LocalStorage
  localStorage.setItem(username, password);
  message.style.color = "green";
  message.textContent = "Đăng ký thành công!";

  setTimeout(() => {
    window.location.href = "loginform.html";
  }, 1500);
}
