let cart = [];

// Xử lý thêm sản phẩm
document.querySelectorAll('.themsanpham').forEach((btn) => {
    btn.addEventListener('click', () => {
        const productElement = btn.closest('.sp');
        const productName = productElement.querySelector('.tensp').innerText;
        const productPriceText = productElement.querySelector('.giatien').innerText;
        const productPrice = parseInt(productPriceText.replace(/[^\d]/g, ''));
        const productImage = productElement.querySelector('img').getAttribute('src');

        const existingItem = cart.find(item => item.name === productName);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                name: productName,
                price: productPrice,
                image: productImage,
                quantity: 1
            });
        }

        // Mở giỏ hàng luôn khi thêm sản phẩm
        document.getElementById('cart-container').style.display = 'block';

        updateCartUI();
    });
});

function updateCartUI() {
    const cartContainer = document.getElementById('cart-container');
    cartContainer.innerHTML = '';

    let totalPrice = 0;

    cart.forEach(item => {
        totalPrice += item.price * item.quantity;

        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');

        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}" onerror="this.src='/agm/img/default.jpg'">
            <div class="cart-item-details">
                <p><strong>${item.name}</strong></p>
                <p>Giá: ${item.price.toLocaleString()}₫</p>
                <p>Số lượng: ${item.quantity}</p>
            </div>
        `;
        cartContainer.appendChild(cartItem);
    });

    const totalDiv = document.createElement('div');
    totalDiv.classList.add('cart-total');
    totalDiv.innerText = `Tổng tiền: ${totalPrice.toLocaleString()}₫`;
    cartContainer.appendChild(totalDiv);

    const checkoutBtn = document.createElement('button');
    checkoutBtn.classList.add('btn', 'btn-checkout');
    checkoutBtn.innerText = 'Thanh toán';
    cartContainer.appendChild(checkoutBtn);
}
